package com.example.aicharacter

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 60, 44, 44)
            setBackgroundColor(0xFF111018.toInt())
        }
        val title = TextView(this).apply {
            text = "AI 像素懸浮角色"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "這一版不再把角色當成一張靜止圖片。\n\n角色會像像素遊戲角色一樣：\n• 自然左右晃動\n• 呼吸／輕微上下浮動\n• 隨機眨眼\n• 點擊可聊天\n• 可以拖到螢幕任何位置"
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 22, 0, 26)
        }
        val start = Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) "啟動像素角色" else "允許懸浮並啟動"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    })
                } else {
                    ContextCompat.startForegroundService(
                        this@MainActivity,
                        Intent(this@MainActivity, FloatingCharacterService::class.java)
                    )
                }
            }
        }
        val stop = Button(this).apply {
            text = "關閉角色"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingCharacterService::class.java))
            }
        }
        box.addView(title); box.addView(info); box.addView(start); box.addView(stop)
        setContentView(box)
    }
}
