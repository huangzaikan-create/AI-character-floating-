package com.example.aicharacter

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlin.math.*
import kotlin.random.Random

class FloatingCharacterService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var view: PixelCharacterView
    private var windowParams: WindowManager.LayoutParams? = null
    private var chat: LinearLayout? = null
    private var chatInput: EditText? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun type() =
        if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(9, notification())
        if (Settings.canDrawOverlays(this)) showCharacter()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("pixel_character", "像素角色",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notification() =
        NotificationCompat.Builder(this, "pixel_character")
            .setContentTitle("AI 像素角色正在陪伴你")
            .setContentText("角色會眨眼和輕微左右晃動")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()

    private fun showCharacter() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = PixelCharacterView(this).apply {
            onTap = { openChat() }
        }

        windowParams = WindowManager.LayoutParams(
            150, 205, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 180
        }

        view.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var px=0; var py=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx=e.rawX; sy=e.rawY
                        px=windowParams!!.x; py=windowParams!!.y; moved=false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=e.rawX-sx; val dy=e.rawY-sy
                        if(abs(dx)>8 || abs(dy)>8) moved=true
                        windowParams!!.x=px+dx.toInt()
                        windowParams!!.y=py+dy.toInt()
                        wm.updateViewLayout(view, windowParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if(!moved) view.onTap?.invoke()
                        return true
                    }
                }
                return true
            }
        })
        wm.addView(view, windowParams)
    }

    private fun openChat() {
        if(chat != null) return
        chat = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(18,18,18,18)
            background=GradientDrawableHelper.round(0xFF171721.toInt(),22)
        }
        val top=LinearLayout(this)
        val title=TextView(this).apply {
            text="像素角色"
            textSize=19f
            setTextColor(Color.WHITE)
        }
        val close=Button(this).apply {
            text="×"
            setOnClickListener { closeChat() }
        }
        top.addView(title,LinearLayout.LayoutParams(0,50,1f))
        top.addView(close,LinearLayout.LayoutParams(60,50))
        chat!!.addView(top)

        val scroll=ScrollView(this)
        val msgs=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            addView(msg("你來啦。今天過得怎麼樣？",false))
        }
        scroll.addView(msgs)
        chat!!.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        val row=LinearLayout(this)
        chatInput=EditText(this).apply {
            hint="跟我說話……"; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt())
        }
        val send=Button(this).apply {
            text="送出"
            setOnClickListener {
                val t=chatInput?.text?.toString()?.trim().orEmpty()
                if(t.isEmpty()) return@setOnClickListener
                msgs.addView(msg(t,true))
                chatInput?.setText("")
                msgs.addView(msg("我收到啦。之後可以把這裡接上 GPT，讓我真的理解你說的每一句話。",false))
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        row.addView(chatInput,LinearLayout.LayoutParams(0,56,1f))
        row.addView(send,LinearLayout.LayoutParams(78,56))
        chat!!.addView(row)

        val cp=WindowManager.LayoutParams(
            900, 1050, type(),
            WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
            PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.CENTER }
        wm.addView(chat,cp)
        chatInput?.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(chatInput,InputMethodManager.SHOW_IMPLICIT)
    }

    private fun msg(s:String, me:Boolean)=TextView(this).apply {
        text=s; textSize=15f; setTextColor(Color.WHITE)
        setPadding(16,12,16,12)
        background=GradientDrawableHelper.round(if(me)0xFF5C4968.toInt() else 0xFF2A2937.toInt(),18)
        layoutParams=LinearLayout.LayoutParams(-2,-2).apply {
            setMargins(8,6,8,6)
        }
    }

    private fun closeChat() {
        chat?.let { wm.removeView(it) }; chat=null; chatInput=null
    }

    override fun onDestroy() {
        closeChat()
        if(::view.isInitialized && view.parent!=null) wm.removeView(view)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null

    object GradientDrawableHelper {
        fun round(color:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply{
            setColor(color); cornerRadius=r.toFloat()
        }
    }
}

class PixelCharacterView(context: Context) : View(context) {
    private val bmp = BitmapFactory.decodeResource(resources, R.drawable.character_pixel)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap=false }
    private var time=0f
    private var blink=0f
    private var nextBlink=3.5f
    private var last=System.nanoTime()
    var onTap:(()->Unit)?=null

    private val tick=object:Runnable{
        override fun run(){
            val now=System.nanoTime()
            val dt=((now-last)/1e9).toFloat().coerceAtMost(.05f)
            last=now; time+=dt
            if(time>=nextBlink){
                blink=1f
                nextBlink=time+Random.nextDouble(2.8,6.2).toFloat()
            }
            blink=max(0f,blink-dt*8f)
            invalidate()
            postOnAnimation(this)
        }
    }

    init { postOnAnimation(tick) }

    override fun onDraw(c:Canvas){
        super.onDraw(c)
        // Pixel-game idle motion: slow side-to-side sway + breathing.
        val sway=sin(time*1.65f)*5f
        val bob=sin(time*2.1f)*2.2f
        c.save()
        c.translate(sway,bob)
        val dst=RectF(8f,4f,width-8f,height-4f)
        c.drawBitmap(bmp,null,dst,paint)

        // A short pixel-style blink strip over the eye area.
        // Coordinates are proportional so it remains stable when resized.
        if(blink>0f){
            val y=height*0.39f
            val h=height*0.025f*blink
            val p=Paint().apply{color=Color.rgb(80,70,80)}
            c.drawRect(width*.31f,y,width*.49f,y+h,p)
            c.drawRect(width*.54f,y,width*.70f,y+h,p)
        }
        c.restore()
    }
}
